## Summary

<!-- Describe the changes -->

## Type of change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Docs/CI only

## Checklist
- [ ] Tests added/updated
- [ ] Docs updated (README/QUALITY_CHECKLIST)
- [ ] CI green
- [ ] Linked issue

## Related
Repo: https://github.com/Bigdaddy1990/pawcontrol
