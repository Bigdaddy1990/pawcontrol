import pytest

@pytest.mark.asyncio
async def test_dummy_services():
    assert True
