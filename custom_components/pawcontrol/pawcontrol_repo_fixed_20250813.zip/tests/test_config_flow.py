import pytest

@pytest.mark.asyncio
async def test_dummy():
    assert True
