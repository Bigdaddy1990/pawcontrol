from __future__ import annotations

from typing import Any
import voluptuous as vol

from homeassistant.core import HomeAssistant
from homeassistant.const import CONF_DEVICE_ID, CONF_DOMAIN, CONF_ENTITY_ID, CONF_TYPE
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.typing import ConfigType
from homeassistant.helpers.config_validation import DEVICE_ACTION_BASE_SCHEMA
from homeassistant.components.device_automation.exceptions import InvalidDeviceAutomationConfig

from .const import DOMAIN
from .schemas import (
    SERVICE_GPS_START_WALK,
    SERVICE_GPS_END_WALK,
    SERVICE_GPS_POST_LOCATION,
    SERVICE_TOGGLE_GEOFENCE_ALERTS,
)

ACTION_TYPES = {
    "post_location",
    "start_walk",
    "end_walk",
    "toggle_geofence_alerts",
}

ACTION_SCHEMA = DEVICE_ACTION_BASE_SCHEMA.extend(
    {
        vol.Required(CONF_TYPE): vol.In(ACTION_TYPES),
        vol.Optional("enabled"): bool,
    }
)

async def async_get_actions(hass: HomeAssistant, device_id: str) -> list[dict[str, Any]]:
    return [
        {CONF_DOMAIN: DOMAIN, CONF_DEVICE_ID: device_id, CONF_TYPE: t}
        for t in ACTION_TYPES
    ]

def _dog_id_from_device_id(hass: HomeAssistant, device_id: str | None) -> str | None:
    if not device_id:
        return None
    dev_reg = dr.async_get(hass)
    dev = dev_reg.async_get(device_id)
    if not dev or not dev.identifiers:
        return None
    for idt in dev.identifiers:
        if idt[0] == DOMAIN:
            return idt[1]
    return None

async def async_call_action_from_config(
    hass: HomeAssistant, config: ConfigType, variables: dict[str, Any], context: Any
) -> None:
    if "type" not in config or "device_id" not in config:
        raise InvalidDeviceAutomationConfig("Missing required keys")

    action_type: str = config[CONF_TYPE]
    device_id: str = config[CONF_DEVICE_ID]
    dog_id = _dog_id_from_device_id(hass, device_id)
    if not dog_id:
        raise InvalidDeviceAutomationConfig("Device has no Paw Control dog identifier")

    if action_type == "start_walk":
        await hass.services.async_call(DOMAIN, SERVICE_GPS_START_WALK, {"dog_id": dog_id}, blocking=True, context=context)
        return
    if action_type == "end_walk":
        await hass.services.async_call(DOMAIN, SERVICE_GPS_END_WALK, {"dog_id": dog_id}, blocking=True, context=context)
        return
    if action_type == "toggle_geofence_alerts":
        enabled = bool(config.get("enabled", True))
        await hass.services.async_call(DOMAIN, SERVICE_TOGGLE_GEOFENCE_ALERTS, {"dog_id": dog_id, "enabled": enabled}, blocking=True, context=context)
        return

    raise InvalidDeviceAutomationConfig(f"Unsupported action type: {action_type}")
