"""Stub package for pytest-cov to satisfy plugin discovery in isolated CI runs."""
