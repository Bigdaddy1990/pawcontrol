"""Placeholder tests for pawcontrol."""


def test_placeholder() -> None:
    """Ensure pytest collects and runs tests."""
    assert True
