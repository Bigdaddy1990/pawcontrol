# Branding for Paw Control

Home Assistant lädt Integrations-Logos/Icons aus dem zentralen **home-assistant/brands** Repository.
Für offizielles Branding bitte dort einen PR einreichen:

- Ordner: `custom_integrations/pawcontrol/`
- Dateien: `icon.svg` (256x256), `logo.svg` (512x512)
- Transparenter Hintergrund, korrekte Benennung

Nach Merge stehen die Assets automatisch in der UI zur Verfügung.
