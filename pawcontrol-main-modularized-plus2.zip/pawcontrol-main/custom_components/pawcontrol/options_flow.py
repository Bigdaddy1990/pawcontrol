"""Options flow entrypoint for the PawControl integration.

This file is intentionally kept small. The full implementation lives in
:mod:`custom_components.pawcontrol.options_flow_main` and composes themed mixins
(e.g. gps/notifications/feeding/health) for maintainability.
"""

from __future__ import annotations

from .options_flow_main import PawControlOptionsFlow

__all__ = ["PawControlOptionsFlow"]
