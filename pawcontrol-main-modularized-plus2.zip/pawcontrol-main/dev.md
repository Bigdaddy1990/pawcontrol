# Developer Guide (PawControl)

This guide covers **local development**, **testing**, and **troubleshooting** for
the PawControl Home Assistant integration. User-facing documentation lives in
`README.md` and the `docs/` folder.

## Local development setup

1. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements_test.txt
   pip install -r requirements.txt
   ```
3. Optional: install the project in editable mode for packaging hooks:
   ```bash
   pip install -e .
   ```

> **Note:** The repository ships local shims in `pytest_cov/` and
> `pytest_homeassistant_custom_component/`. Avoid installing the PyPI variants
> alongside this repo to prevent plugin conflicts.

## Running locally with Home Assistant

1. Copy the integration to your HA config:
   ```bash
   cp -r custom_components/pawcontrol /config/custom_components/
   ```
2. Restart Home Assistant.
3. Add the integration from **Settings → Devices & Services**.

## Architecture overview

PawControl follows the Home Assistant **config entry + coordinator** pattern.
High-level architecture:

```mermaid
flowchart LR
  subgraph Home_Assistant
    UI[HA UI / Automations]
    Services[Service Calls]
    Entities[Entities]
  end

  subgraph PawControl
    ConfigEntry[Config Entry]
    Coordinator[DataUpdateCoordinator]
    Managers[Feature Managers<br/>Walk • Feeding • Garden • Health]
    DataManager[Persistence + Runtime Data]
  end

  UI --> Entities
  Services --> Managers
  ConfigEntry --> Coordinator
  Coordinator --> Managers
  Managers --> DataManager
  DataManager --> Entities
```

### Runtime data flow

```mermaid
sequenceDiagram
  participant HA as Home Assistant
  participant CE as Config Entry
  participant CO as Coordinator
  participant MG as Manager
  participant DM as Data Manager

  HA->>CE: Setup integration
  CE->>CO: Start coordinator
  CO->>MG: Refresh data
  MG->>DM: Persist updates
  DM-->>CO: Provide normalized data
  CO-->>HA: Update entities
```

## Async & concurrency guidelines

- **Everything that touches HA must be async**: use `async def` and await on
  I/O, coordinator refreshes, or service handlers.
- **Never block the event loop**: wrap blocking work with
  `hass.async_add_executor_job`.
- **Centralize polling in the coordinator**: entities should read from
  coordinator data rather than calling APIs directly.
- **Avoid race conditions**: schedule changes via the data manager and reuse
  shared guards, rather than creating new background tasks.

## Typing guidelines

- Keep **strict typing** (`mypy` runs in strict mode). Avoid implicit
  optionals and untyped returns.
- Add new models to `types.py` and reuse existing type aliases.
- Use Home Assistant type aliases (`ConfigEntry`, `HomeAssistant`, `Platform`)
  consistently to keep annotations aligned with HA.

### JSON-safe attributes

- All `extra_state_attributes` implementations must return a
  `JSONMutableMapping` and **must not** leak `datetime`, `timedelta`, sets, or
  other complex objects.
- Use `custom_components.pawcontrol.diagnostics.normalize_value()` (and its
  `_normalise_json` wrapper) to normalise payloads before returning them.

> Note: The integration already contains a top-level `utils.py` module.
> Avoid adding a `utils/` package directory, as it would conflict with
> `pawcontrol.utils` imports.


## Flow structure

The Home Assistant entrypoint modules are intentionally kept **small**:

- `custom_components/pawcontrol/config_flow.py` → imports the full implementation from
  `custom_components/pawcontrol/config_flow_main.py`
- `custom_components/pawcontrol/options_flow.py` → imports the full implementation from
  `custom_components/pawcontrol/options_flow_main.py`

The large flows are composed from themed mixins to keep responsibilities separated:

- Config flow mixins live in `config_flow_*.py` (dogs, modules, profile, dashboard, reauth, external, …)
- Options flow mixins live in `options_flow_*.py` and are grouped by domain:

  - `options_flow_menu.py` → main menu step (`async_step_init`)
  - `options_flow_profiles.py` → entity profiles + performance settings
  - `options_flow_dogs_management.py` → dog CRUD + per-dog module configuration
  - `options_flow_door_sensor.py` → per-dog door-sensor configuration
  - `options_flow_system_settings.py` → weather / system / dashboard / advanced settings
  - `options_flow_import_export.py` → import/export helpers + UI steps
  - `options_flow_gps.py`, `options_flow_notifications.py`, `options_flow_feeding.py`, `options_flow_health.py` → feature domains
  - `options_flow_shared.py` → shared helpers used across multiple mixins (telemetry, manual events, typed builders)


When adding new steps, prefer extending an existing themed mixin (or creating a new one)
instead of growing the `*_main.py` modules.


## Quality gate (run before PR)

```bash
ruff format
ruff check
python -m script.enforce_test_requirements
mypy custom_components/pawcontrol
pytest -q
python -m script.hassfest --integration-path custom_components/pawcontrol
python -m script.sync_contributor_guides
```

## Localization workflow

Missing translation keys are a common cause of `hassfest` failures.

1. Add new user-facing strings to `custom_components/pawcontrol/strings.json`.
2. Propagate them to all locale files under
   `custom_components/pawcontrol/translations/`.
3. Re-run `python -m script.hassfest --integration-path custom_components/pawcontrol`
   to validate schema and localization.

## Testing strategy

Target **unit coverage for every entity type and flow**, including normal and
error paths:

- Config flow, options flow, and reauth scenarios
- Coordinator update failures and retry handling
- Service validation and side effects
- Diagnostics redaction
- Entity behavior for typical + failure paths (e.g., missing API token,
  invalid geofence coordinates, timeout handling)

Use `pytest` fixtures and the Home Assistant stubs in
`tests/helpers/homeassistant_test_stubs.py` to simulate core behavior without a
full HA runtime. Always exercise both successful and rejected paths by crafting
fixtures for missing API tokens, invalid geofence inputs, or timeout
conditions.

### Measuring coverage (without committing artifacts)

```bash
pytest -q --cov custom_components/pawcontrol --cov-report=term-missing
```

- Do **not** commit generated artifacts such as `.coverage*` or `htmlcov/`.
- Publish HTML coverage via CI artifacts or GitHub Pages instead.

## Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| `ImportError` for HA modules | Stubs not loaded or missing dependencies | Ensure tests call `install_homeassistant_stubs()` and requirements are installed. |
| `hassfest` failures | Missing keys in `strings.json` | Add new strings and sync `translations/*.json`. |
| `mypy` errors | Untyped returns/optionals | Update annotations; avoid implicit optionals. |
| `pytest` failures on coverage | Missing tests or uncovered error paths | Add unit tests for invalid inputs (e.g., geofence radius, missing API token). |

## Release checklist (dev-side)

- Update `CHANGELOG.md` with user-visible changes.
- Ensure new docs link to evidence (tests, diagnostics, workflows).
- Re-run the quality gate commands before tagging a release.
